# dxf2svg

Convert from dxf files using dxf-grabber and linearize splines using NURBS-Python

